// Copyright (c) Thorsten Beier
// Copyright (c) JupyterLite Contributors
// Distributed under the terms of the Modified BSD License.

declare module '*.png' {
  const value: string;
  export default value;
}
