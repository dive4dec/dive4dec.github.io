.. _installation:

Installation
============

You can install ``dive-jupyterlite-xeus-python`` with ``pip``:

.. code::

    pip install jupyterlite dive-jupyterlite-xeus-python

    # This should pick up the xeus-python kernel automatically
    jupyter lite build
